/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-afac4cd2'], (function (workbox) { 'use strict';

  self.skipWaiting();
  workbox.clientsClaim();
  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "registerSW.js",
    "revision": "1872c500de691dce40960bb85481de07"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "e817b1fc51a9da11fd7c08fff73bda1e"
  }, {
    "url": "pwa-512x512.png",
    "revision": "e817b1fc51a9da11fd7c08fff73bda1e"
  }, {
    "url": "pwa-192x192.png",
    "revision": "fa8ff0eb94f5269877dccf50b116e05c"
  }, {
    "url": "og-image.png",
    "revision": "e817b1fc51a9da11fd7c08fff73bda1e"
  }, {
    "url": "index.html",
    "revision": "0336bb094abc8a11f27dcaafa5739aca"
  }, {
    "url": "icon.svg",
    "revision": "0a56e3ae00948ccdedf79b32d60b5301"
  }, {
    "url": "apple-touch-icon.png",
    "revision": "6fe2a77a1245ee0513e8e2473f5f0cda"
  }, {
    "url": "assets/purify.es-DBIK8olT.js",
    "revision": null
  }, {
    "url": "assets/index.es-x6EB3oD3.js",
    "revision": null
  }, {
    "url": "assets/index-ssOss4td.js",
    "revision": null
  }, {
    "url": "assets/index-BBByD5U_.css",
    "revision": null
  }, {
    "url": "apple-touch-icon.png",
    "revision": "6fe2a77a1245ee0513e8e2473f5f0cda"
  }, {
    "url": "icon.svg",
    "revision": "0a56e3ae00948ccdedf79b32d60b5301"
  }, {
    "url": "pwa-192x192.png",
    "revision": "fa8ff0eb94f5269877dccf50b116e05c"
  }, {
    "url": "pwa-512x512.png",
    "revision": "e817b1fc51a9da11fd7c08fff73bda1e"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "e817b1fc51a9da11fd7c08fff73bda1e"
  }, {
    "url": "manifest.webmanifest",
    "revision": "bef94b788dd0ea77c1f20aa8fa413af4"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("index.html"), {
    denylist: [/^\/api\//, /^https:\/\/.*turso\.io/]
  }));
  workbox.registerRoute(/^https:\/\/fonts\.googleapis\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "google-fonts-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 10,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');
  workbox.registerRoute(/^https:\/\/fonts\.gstatic\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "gstatic-fonts-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 10,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');
  workbox.registerRoute(/^https:\/\/cdnjs\.cloudflare\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "cdn-fa-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 20,
      maxAgeSeconds: 2592000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');

}));
